# coding: utf-8
from flask import Flask, render_template, url_for, redirect, request, flash, session, jsonify, make_response
from flask_mail import Mail
import os
from flask_bootstrap import Bootstrap
from datetime import datetime
import peewee
from flask_sqlalchemy import SQLAlchemy
from flask_admin import Admin
from flask_admin.contrib.sqla import ModelView

# use the stripe keys to handle the payment
stripe_keys = {
    'secret_key': os.getenv('SECRET_KEY'),
    'publishable_key': os.getenv('PUBLISHABLE_KEY')
}
pem = os.getenv('PEM')  # todo add to production envrionment path
db_username = os.getenv('DB_USERNAME')
db_password = os.getenv('DB_PASSWORD')
application = Flask(__name__, template_folder="templates")
application.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
application.config[
    'SQLALCHEMY_DATABASE_URI'] = r'mysql+pymysql://{}:{}@aag9gabvtjs2x6.ccc5n71qqwsa.us-east-2.rds.amazonaws.com:3306/luckyvr'.format(db_username,db_password)
application.secret_key = os.getenv('APP_SECRET_KEY')
mail_password = os.environ.get('MAIL_PASSWORD')  # todo add to production envrionment path

mail_settings = {
    "MAIL_SERVER": 'smtp.gmail.com',
    "MAIL_PORT": 465,
    "MAIL_USE_TLS": False,
    "MAIL_USE_SSL": True,
    "MAIL_USERNAME": 'abinlaa@gmail.com',
    "MAIL_PASSWORD": mail_password
}

application.config.update(mail_settings)
mail = Mail(application)
bootstrap = Bootstrap(application)

#peewee solution need to be replace ---------------------------------------------------
# peewee database solution
db = peewee.MySQLDatabase("luckyvr", host="aag9gabvtjs2x6.ccc5n71qqwsa.us-east-2.rds.amazonaws.com", port=3306,
                          user="abinla", passwd="itc98004")


class ContactModel(peewee.Model):
    name = peewee.CharField(default="")
    email = peewee.CharField(default="")
    size = peewee.CharField(default="")
    type = peewee.CharField(default="")
    promotion_code = peewee.CharField(default="")
    extra = peewee.CharField(default="")
    timestamp = peewee.DateTimeField(default=datetime.now)

    class Meta:
        database = db


ContactModel.create_table()
#peewee solution need to be replace ---------------------------------------------------

# SQLAlchemy database solution
database = SQLAlchemy(application)
admin = Admin(application)


class Unsubscribe(database.Model):
    id = database.Column(database.Integer, primary_key=True)
    mobile = database.Column(database.String(20),unique=True)
    created_date = database.Column(database.DateTime, default=datetime.utcnow)

class Scanned(database.Model):
    id = database.Column(database.Integer, primary_key=True)
    pid = database.Column(database.String(30), nullable=False) #property id used in luckyvr.net/property/<id>
    lat = database.Column(database.Numeric(12,7), nullable=False)                 #property's latlng
    lng = database.Column(database.Numeric(12,7), nullable=False)                 #property's latlng
    mlink = database.Column(database.String(120),unique=True,nullable=False)    #matterport scan link
    address = database.Column(database.String(120),unique=True)    #property address
    listing_type = database.Column(database.String(20),default="res_sal")    #property type:residential&commertial&boat

    created_date = database.Column(database.DateTime, default=datetime.utcnow)


admin.add_view(ModelView(Unsubscribe, database.session))
admin.add_view(ModelView(Scanned, database.session))


database.create_all()


# route to show index/home page
@application.route('/index')
@application.route("/", methods=['GET', 'POST'])
def index():
    return render_template("index.html")

# route to show property directly
@application.route('/property/<id>')
def property(id):
    # redirect(url_for('index') + '#myModal')
    record = Scanned.query.filter_by(pid=id.lower()).first()
    if record.mlink:
        # mlink = 'https://my.matterport.com/show/?m=cpm1cEf5uuX'
        return render_template("property.html",mlink=record.mlink)
    else:
        return redirect(url_for('index'))

if __name__ == "__main__":
    # application.run(host="192.168.20.8",debug=True)
    application.run(host="192.168.20.8", debug=True, ssl_context='adhoc')
